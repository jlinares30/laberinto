#pragma once
using namespace System;

void ubicar(float x, float y)
{
    Console::SetCursorPosition(x, y);
}